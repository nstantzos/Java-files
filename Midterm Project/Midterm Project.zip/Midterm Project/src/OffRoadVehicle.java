public class OffRoadVehicle extends Vehicle implements OffRoadInterface
{

	public OffRoadVehicle(String vehicleName, String vehicleType, int currentSpeed, int maxSpeed, int position, int pitStopFrequency, boolean hasTurbo) 
	{
		super(vehicleName, vehicleType, offRoadVehicleStartingSpeed, offRoadVehicleMaxSpeed, position, offRoadVehiclePitStopFrequency, offRoadVehicleHasTurbo);
		// TODO Auto-generated constructor stub
	}

}
