
public interface StockCarInterface 
{
	public static int stockCarPitStopFrequency = 0;
	public static boolean stockCarHasTurbo = false;
	public static int stockCarMaxSpeed = 100;
}
