
public class StockCar extends Vehicle implements StockCarInterface
{

	public StockCar(String vehicleName, String vehicleType, int currentSpeed, int maxSpeed, int position, int pitStopFrequency, boolean hasTurbo) 
	{
		super(vehicleName, vehicleType, stockCarMaxSpeed, stockCarMaxSpeed, position, stockCarPitStopFrequency, stockCarHasTurbo);
		// TODO Auto-generated constructor stub
	}

}
