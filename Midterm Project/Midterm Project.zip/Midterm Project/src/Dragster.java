public class Dragster extends Vehicle implements DragsterInterface
{

	public Dragster(String vehicleName, String vehicleType, int currentSpeed, int maxSpeed, int position, int pitStopFrequency, boolean hasTurbo) 
	{
		super(vehicleName, vehicleType, dragsterStartingSpeed, dragsterMaxSpeed, position, dragsterPitStopFrequency, dragsterHasTurbo);
		// TODO Auto-generated constructor stub
	}

}
