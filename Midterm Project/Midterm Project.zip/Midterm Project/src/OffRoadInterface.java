
public interface OffRoadInterface 
{
	public static int offRoadVehiclePitStopFrequency = 2;
	public static boolean offRoadVehicleHasTurbo = true;
	public static int offRoadVehicleStartingSpeed = 200;
	public static int offRoadVehicleMaxSpeed = 200;
}
