
public interface DragsterInterface 
{

	public static int dragsterPitStopFrequency = 1;
	public static boolean dragsterHasTurbo = true;
	public static int dragsterMaxSpeed = 10000;
	public static int dragsterStartingSpeed = 10;

}
